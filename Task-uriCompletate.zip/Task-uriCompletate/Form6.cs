﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows;
using GoogleApi.Entities.Places.Search.Text.Response;
using Xceed.Wpf.Toolkit.Panels;
using Google.API.Search;

namespace Task_uriCompletate
{
    public partial class Form6 : Form
    {
        private object SearchFilter;

        public Form6()
        {
            InitializeComponent();
            SearchFilter.ItemsSource = new List<SafeLevel> { SafeLevel.Active, SafeLevel.Moderate, SafeLevel.Off };
            SearchFilter.SelectedItem = SafeLevel.Moderate;
        }

        public object SafeLevel { get; }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                WrapPanel.Children.Clear();
                GimageSearchClient client = new GimageSearchClient("http://www.google.com");
                IList<IImageResult> results;

                IAsyncResult result = client.BeginSearch(
                    textSearch.Text.Trim(),  //param1
                    int.Parse(TextResult.Text), //param2
                    ((arResult) => //param3
                    {
                        results = client.EndSearch(arResult);
                        Dispatcher.Invoke(DispatcherPriority.Send,
                            (Action<IList<IImageResult>>)(async (data) =>
                            {
                                for (int i = 0; i < results.Count; i++)
                                {
                                    Image img = new Image
                                    {
                                        Source = await DownloadImage(results[i].TbImage.Url),
                                        Stretch = Stretch.UniformToFill,
                                        StretchDirection = StretchDirection.DownOnly,
                                    };
                                    wrapPanel.Children.Add(img);
                                }
                            }), null);
                    }),
                    null //param4
                    );
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
        }
    }
}
